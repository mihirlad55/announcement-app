/********************************
**  Announcement Home	       ** 
**                             **
** Mihir lad			       **
** ICS3U                       **
** Ver 1.0 - October 18, 2016  **
********************************/


/*global optimizeGeneralLayout animateControl generalLoad $ showModalAlertOkOnly showModalAlertYesNo closeModal*/
function onLoad()
{
	"use strict";

	generalLoad();

	window.setTimeout(animateControl, 800, '#main', 'slideInDown', false);

	document.getElementById("txtUsername").addEventListener("keyup", function(event)
	{
		event.preventDefault();
		if (event.keyCode == 13) login();
	});
	
	
	document.getElementById("txtPassword").addEventListener("keyup", function(event)
	{
		event.preventDefault();
		if (event.keyCode == 13) login();
	});
}


//adjust size of logo according to screen size
window.onresize = function() {
	"use strict";
	
	generalLoad();
};


function login()
{
	$.ajax({
		url: "/teachers/php/login.php",
		type: "GET",
		data: {
			"username": $("#txtUsername").val(),
			"password": $("#txtPassword").val()
		},
		success: function(response)
		{
			if (response.toLowerCase().match("invalid username or password"))
			{
				showModalAlertOkOnly("Login Failed", "Incorrect Username or Password");
			}
			else
			{
				showModalAlertOkOnly("Login Successful", "Welcome", function() { window.location.href="/teachers/view" });
			}
		}
	});
}

