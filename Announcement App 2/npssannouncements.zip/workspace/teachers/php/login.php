<?php

$result;
$conn;

	//if the script is called by a get request, then continue
	 if ($_SERVER['REQUEST_METHOD'] === 'GET')
    {
		//create constant variables to hold the details of the sql server and credentials
		define("DB_NAME", "id69779_announcements");
		define("DB_USER", "id69779_root");
		define("DB_HOST", "localhost");
		define("DB_PASSWORD", "145willow21");
		
		//connect to the sql databse
		$conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
		
		//if connection fails, exit and send error message
		if ($conn->connect_error) {
			die("Could not connect: " . $conn->connect_error);
		}
		
		$username = strtolower($conn->real_escape_string($_GET["username"]));
		$password = $_GET["password"];

		if ($username != "" && $password != "")
		{
	    	if (sendQuery("SELECT salt FROM " . DB_NAME . ".users WHERE username='" . $username . "'"))
	    	{
	    		$salt = $result->fetch_assoc()["salt"];
	    		$hashedPassword = hash_pbkdf2 ("sha256", $password, $salt, 10, 60);
	    		  
	        	if (sendQuery("SELECT username FROM " . DB_NAME . ".users WHERE password='" . $hashedPassword . "'"))
	        	{
	        		$resultUsername = ($result->fetch_assoc());
	        	    if ($resultUsername["username"] == $username)
	        	    {
	        	    	if (sendQuery("SELECT name FROM " . DB_NAME . ".users WHERE username='" . $username . "'"))
	        	    	{
			        	    $name = $result->fetch_assoc()["name"];
	        	    /*		if (sendQuery("SELECT sessionID FROM " . DB_NAME . ".sessions WHERE username='" . $username ."'"))
	        	    		{ */
	        	    			$name;
	        	    		/*	if ($result->fetch_assoc()["sessionID"] == null)
	        	    			{ */
			        	    		session_start();
			        	    		$_SESSION["name"] = $name;
			        	    		setcookie("name", $name, 0, "/");
			        	    		$_SESSION["isTeacher"] = true;
				        	       // sendQuery("INSERT INTO " . DB_NAME . ".sessions VALUES(NULL,'" . session_id() . "','" . $username . "')", false);
	        	    				session_write_close();
	        	    		/*	}
	        	    			else
	      	    				{
	
	        	    			} 
	        	    		}*/
	
	        	    	}
	        	    }
	        	    else
	        	    {
	        	    	exit("invalid username or password");
	        	    }
	        	}
	    	}
		}
		else
		{
			exit("invalid username or password");
		}
	}
    
    
function sendQuery($queryString, $showError = true)
{
	global $conn, $result;
	if ($result = $conn->query($queryString))
    {
    	return true;
    }
    else
    {
    	if ($showError) die("Error: " . $conn->error);	
    }
}
    
    
    /*     	if ($result = $conn->query($command))
    	{
    		$salt = $result->fetch_assoc()["salt"];
    		$hashedPassword = hash_pbkdf2 ("sha256", $password, $salt, 10, 60);
    		  
    		$command = "SELECT username FROM " . DB_NAME . ".users WHERE password='" . $hashedPassword . "'";
        	if ($conn->query($command))
        	{
        	    $result = $conn->query($command);
        	    if ($result->fetch_assoc()["username"] == $username)
        	    {
        	    	$command = "SELECT name FROM " . DB_NAME . ".users WHERE username='" . $username . "'";
        	    	
        	    	if ($result = $conn->query($command))
        	    	{
        	    		session_start();
	        	        echo session_id() . ";";
        	    	}
        	    	else
        	    	{
        				die("Error: " . $conn->error);	
        	    	}

        	    }
        	    else
        	    {
        	    	echo "invalid username or password";
        	    }
        	}
        	else
        	{
        	    die("Error: " . $conn->error);	
        	}
		}
		else
		{
		   die("Error: " . $conn->error);	
		}*/
?>