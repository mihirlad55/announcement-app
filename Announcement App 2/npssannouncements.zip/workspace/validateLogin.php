<?php

    function validateLogin()
    {
        session_start();
        if (!isset($_SESSION["isTeacher"]) && !$_SESSION["isTeacher"] == true)
        {
            header("Location: /students/view");
        }
        session_write_close();
    }

?>