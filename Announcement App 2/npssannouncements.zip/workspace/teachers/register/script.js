/********************************
**  Announcement Home	       ** 
**                             **
** Mihir lad			       **
** ICS3U                       **
** Ver 1.0 - October 18, 2016  **
********************************/


/*global optimizeGeneralLayout animateControl generalLoad $ showModalAlertOkOnly showModalAlertYesNo closeModal*/
function onLoad()
{
	"use strict";

	generalLoad();

	window.setTimeout(animateControl, 800, '#main', 'slideInDown', false);

	document.getElementById("txtUsername").addEventListener("keyup", function(event)
	{
		event.preventDefault();
		if (event.keyCode == 13) login();
	});
	
	
	document.getElementById("txtPassword").addEventListener("keyup", function(event)
	{
		event.preventDefault();
		if (event.keyCode == 13) login();
	});
}


//adjust size of logo according to screen size
window.onresize = function() {
	"use strict";
	
	generalLoad();
};


function register()
{
	var validInfo = true;
	
	if (document.getElementById("txtPassword").value != document.getElementById("txtPasswordConfirmation").value)
	{
		validInfo = false;
		showModalAlertOkOnly("Error", "Make sure passwords are matching.");
	}
	
	if (document.getElementById("txtName").value.trim() == "" && validInfo)
	{
		validInfo = false;
		showModalAlertOkOnly("Error", "Please enter a name.");
	}
	if (document.getElementById("txtPassword").value.trim() == "" && validInfo )
	{
		validInfo = false;
		showModalAlertOkOnly("Error", "Please enter a valid password");
	}
	if (document.getElementById("txtPassword").value.length <= 8 && validInfo)
	{
		validInfo = false;
		showModalAlertOkOnly("Error", "Make sure your password is greater than 8 characters.");
	}
	if (document.getElementById("txtUsername").value.trim() == "" && validInfo)
	{
		validInfo = false;
		showModalAlertOkOnly("Error", "Please enter a valid username.");
	}
	if (document.getElementById("txtUsername").value.length <= 5 && validInfo)
	{
		validInfo = false;
		showModalAlertOkOnly("Error", "Please enter a username greater than 5 characters.");
	}
	
	if (validInfo)
	{
		$.ajax(
		{
			url: "/teachers/php/register.php",
			type: "POST",
			data: {
				"username": document.getElementById("txtUsername").value,
				"password": document.getElementById("txtPassword").value,
				"name": document.getElementById("txtName").value
			},
			success: function(response)
			{
				if (response.toLowerCase().match("error"))
				{
					showModalAlertOkOnly("Registration failed", response);
				}
				else
				{
					showModalAlertOkOnly("Registration Successful", "Welcome " + document.getElementById("txtName").value, function()
					{
						login();
					});
				}
			}
	});
	}
}


function login()
{
	$.ajax({
		url: "/teachers/login//teachers/php/login.php",
		type: "GET",
		data: {
			"username": document.getElementById("txtUsername").value,
			"password": document.getElementById("txtPassword").value
			},
		success: function(response)
		{
			if (response.toLowerCase().match("invalid username or password"))
			{
				showModalAlertOkOnly("Login Failed", "Incorrect Username or Password");
			}
			else
			{
				showModalAlertOkOnly("Login Successful", "Welcome " + getCookie("name"), function() { window.location.href="/teachers/view" });
			}
		}
	});
}