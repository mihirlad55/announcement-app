/********************************
 **  Announcement Creator       ** 
 **                             **
 ** Mihir lad			       **
 ** ICS3U                       **
 ** Ver 1.0 - October 18, 2016  **
 ********************************/

/*global optimizeGeneralLayout animateControl generalLoad $ showModalAlertOkOnly navigateTo*/

var subjectList;
var teacherList;
var targetList = [ "Male Students", "Female Students" ]

function onLoad()
{
	"use strict";

	generalLoad();
	
	window.setTimeout(animateControl, 800, '#main', 'slideInDown', false);
	getFilterOptions();
}


//adjust sizes when window is resized
window.onresize = function() {
	"use strict";
	
	optimizeGeneralLayout();
};


function getFilterOptions()
{
	$.ajax({
		url: "/teachers/php/getFilterOptions.php",
		type: "GET",
		cache: false,
		success: function(response)
		{
			var response = JSON.parse(response);
			subjectList = JSON.parse(response[0]);
			teacherList = JSON.parse(response[1]);
			
			addTeacherCheckBoxes();
			addSubjectCheckBoxes();
			getSettings();
			
			if (parseInt($("#subjectBox").height()) <= parseInt($("#teacherBox").height()))
			{
				$("#boxContainer").css("height", ($("#teacherBox").height() * 1.1).toString() + "px");
			}
			else
			{
				$("#boxContainer").css("height", ($("#subjectBox").height() * 1.1).toString() + "px");
			}
		}
	});
}



function addSubjectCheckBoxes()
{
	for (var i = 0; i < subjectList.length; i++)
	{
		var htmlString = "<div class='checkBoxContainer' onclick='subjectCheck(" + i.toString() + ");'><div class='checkBoxCustom' id='checkBoxCustomSubject" + i.toString() + "'></div>" +
	                "<label>" + subjectList[i] + "</label>" +
	            "</div>";
	    
	    $("#subjectBox").append(htmlString);
	}
}


function addTeacherCheckBoxes()
{
	for (var i = 0; i < teacherList.length; i++)
	{
		var htmlString = "<div class='checkBoxContainer' onclick='teacherCheck(" + i.toString() + ");'><div class='checkBoxCustom' id='checkBoxCustomTeacher" + i.toString() + "'></div>" +
	                "<label>" + teacherList[i] + "</label>" +
	            "</div>";
	    
	    $("#teacherBox").append(htmlString);
	}
}


function saveSettings()
{
	var subjectSettings = [ ];
	var teacherSettings = [ ];
	var targetSettings = [ ];
	
	for (var i = 0; i < subjectList.length; i++)
	{
		if ($("#checkBoxCustomSubject" + i.toString()).hasClass("customChecked"))
		{
			subjectSettings.push(subjectList[i]);
		}
	}
	
	for (var i = 0; i < teacherList.length; i++)
	{
		if ($("#checkBoxCustomTeacher" + i.toString()).hasClass("customChecked"))
		{
			teacherSettings.push(teacherList[i]);
		}
	}
	
	for (var i = 0; i < targetList.length; i++)
	{
		if ($("#checkBoxCustomTarget" + i.toString()).hasClass("customChecked"))
		{
			targetSettings.push(targetList[i]);
		}
	}
	
	localStorage.setItem("subjectSettings", JSON.stringify(subjectSettings));
	localStorage.setItem("teacherSettings", JSON.stringify(teacherSettings));
	localStorage.setItem("targetSettings", JSON.stringify(targetSettings));
	
	showModalAlertOkOnly("Info", "Your preferences have been saved!", function() { window.location.href = "/students"; });
}


function getSettings()
{
	var subjectSettings = JSON.parse(localStorage.getItem("subjectSettings"));
	var teacherSettings = JSON.parse(localStorage.getItem("teacherSettings"));
	var targetSettings = JSON.parse(localStorage.getItem("targetSettings"));
	
	if (subjectSettings != null)
	{
		for (var i = 0; i < subjectList.length; i++)
		{
			if (subjectSettings.indexOf(subjectList[i]) != -1)
			{
				$("#checkBoxCustomSubject" + i.toString()).addClass("customChecked");
			}
			
			if (subjectList[i] == "School")
			{
				$("#checkBoxCustomSubject" + i.toString()).addClass("customChecked");
				$("#checkBoxCustomSubject" + i.toString()).parent().css("background-color", "#b7b7b7");
			}
		}
	}

	if (teacherSettings != null)
	{
		for (var i = 0; i < teacherList.length; i++)
		{
			if (teacherSettings.indexOf(teacherList[i]) != -1)
			{
				$("#checkBoxCustomTeacher" + i.toString()).addClass("customChecked");
			}
		}
	}
	
	if (targetSettings != null)
	{
		for (var i = 0; i < targetList.length; i++)
		{
			if (targetSettings.indexOf(targetList[i]) != -1)
			{
				$("#checkBoxCustomTarget" + i.toString()).addClass("customChecked");
			}
		}
	}
}


function subjectCheck(num)
{
	if (subjectList[num] != "School")
	{
		if ($("#checkBoxCustomSubject" + num.toString()).hasClass("customChecked"))
		{
			$("#checkBoxCustomSubject" + num.toString()).removeClass("customChecked");
		}
		else
		{
			$("#checkBoxCustomSubject" + num.toString()).addClass("customChecked");
		}
	}
}

function teacherCheck(num)
{
	if ($("#checkBoxCustomTeacher" + num.toString()).hasClass("customChecked"))
	{
		$("#checkBoxCustomTeacher" + num.toString()).removeClass("customChecked");
	}
	else
	{
		$("#checkBoxCustomTeacher" + num.toString()).addClass("customChecked");
	}
}

function targetCheck(num)
{
	if ($("#checkBoxCustomTarget" + num.toString()).hasClass("customChecked"))
	{
		$("#checkBoxCustomTarget" + num.toString()).removeClass("customChecked");
	}
	else
	{
		$("#checkBoxCustomTarget" + num.toString()).addClass("customChecked");
	}
}

function checkAllTeachers()
{
	for (var i = 0; i < teacherList.length; i++)
	{
		$("#checkBoxCustomTeacher" + i.toString()).addClass("customChecked");
	}
}

function uncheckAllTeachers()
{
	for (var i = 0; i < teacherList.length; i++)
	{
		$("#checkBoxCustomTeacher" + i.toString()).removeClass("customChecked");
	}
}

function checkAllSubjects()
{
	for (var i = 0; i < subjectList.length; i++)
	{
		$("#checkBoxCustomSubject" + i.toString()).addClass("customChecked");
	}
}

function uncheckAllSubjects()
{
	for (var i = 0; i < subjectList.length; i++)
	{
		$("#checkBoxCustomSubject" + i.toString()).removeClass("customChecked");
	}
}