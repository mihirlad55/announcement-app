/********************************
 **  Announcement Creator       ** 
 **                             **
 ** Mihir lad			       **
 ** ICS3U                       **
 ** Ver 1.0 - October 18, 2016  **
 ********************************/


var title, content, teacherName, subject, deadline, target, place;
var $;
var isMobileDevice = false;

function onLoad()
{
	"use strict";

	isMobileDevice = (/Android|SamsungBrowser|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) ? true : false;

	refreshYears();
	window.setTimeout(animateControl, 800, '#main', 'slideInDown', false);
	
	if (isMobileDevice)
	{
		$('#main').css('width', '100%');
		$('#btnShowMenu').removeClass('invisible');
		$('#navbar').addClass(" invisible");
		$('#headerLogo').addClass(' invisible');
		$('#containerHeader').addClass(' containerHeaderMobile');
		$('#headerTitle').addClass(' headerTitleMobile');
		$('#btnShowMenu').addClass(' btnShowMenuMobile');
	}
	else
	{
		$('#main').css('min-width', (parseInt($(window).width()) * 0.3).toString() + "px");
		$('#main').css('width', parseInt($(window).width() * 0.6, 10));
		$('#main').css('padding-top', (parseInt($("#containerHeader").height()) * 1.5).toString() + "px");
	}
	optimizeLayout();
}



//save dataa
function saveData()
{
	"use strict";

	var dropDownMonth = document.getElementById("dropDownMonth");
	var dropDownDay = document.getElementById("dropDownDay");
	var dropDownYear = document.getElementById("dropDownYear");
	
	//get announcement details from textboxes
	title = document.getElementById("txtTitle").value;
	content = document.getElementById("txtContent").value;
	teacherName = document.getElementById("txtTeacherName").value;
	place = document.getElementById("txtLocation").value;
	subject = document.getElementById("dropDownSubject").value.toString();
	target = $('#dropDownTarget').val();
	
	
	var validAnnouncementFormat = true;
	
	var deadlineMonth = dropDownMonth.selectedIndex;

	//if month is a digit, add zero before it to make it 2 digits to avoid errors in sql query
	if (deadlineMonth.toString().length === 1)
	{
		deadlineMonth = "0" + deadlineMonth.toString();
	}

	//get announcement deadline from dropdown and ensure valid selections
	if (dropDownYear.value != "Year" && dropDownDay.value != "Day" && dropDownMonth.value != "Month")
	{
		deadline = dropDownYear.value + deadlineMonth + dropDownDay.value;
	}
	else if (dropDownYear.value == "Year" && dropDownMonth.value == "Month" && dropDownDay.value == "Day")
	{
		deadline = "";
	}
	else
	{
		alert("Please select a valid deadline or keep deadline blank.")
		validAnnouncementFormat = false;
	}


	if (validAnnouncementFormat)
	{
		//create announcement object
		var announcement = {
			"title": title,
			"teacherName": teacherName,
			"subject": subject,
			"content": content,
			"location": place,
			"deadline": deadline,
			"target" : target
		};
	
		sendAnnouncementToPHP(announcement);
	}
}



//send post request to php script with announcement details
function sendAnnouncementToPHP(announcement)
{
	"use strict";

	$.ajax(
	{
		url: 'addAnnouncement.php',
		type: 'POST',
		data:
		{
			"title": announcement.title,
			"teacherName": announcement.teacherName,
			"subject": announcement.subject,
			"content": announcement.content,
			"location": announcement.location,
			"deadline": announcement.deadline,
			"target": announcement.target
		},
		//alert response from php
		success: function(response)
		{
			alert(response);
			window.location.href = "/teacherview";
		}
	});
	
}



//refresh the number of days in the dropdown based on which month it is. e.g. January: add 31 days, April: add 30 days
function refreshDays()
{
	"use strict";

	document.getElementById("dropDownDay").disabled = false;
	var dropDownMonth = document.getElementById("dropDownMonth");
	var dropDownDay = document.getElementById("dropDownDay");

	var numOfDays = 30;

	//if index of month selected is a month with 31 days, set numOfDays to 31
	if (dropDownMonth.selectedIndex === 1 || dropDownMonth.selectedIndex === 3 || dropDownMonth.selectedIndex === 5 || dropDownMonth.selectedIndex === 7 || dropDownMonth.selectedIndex === 8 || dropDownMonth.selectedIndex === 10 || dropDownMonth.selectedIndex === 12)
	{
		numOfDays = 31;
	}

	//clear dropdown, but keep "Day" option
	while (dropDownDay.lastChild.value !== "Day")
	{
		dropDownDay.removeChild(dropDownDay.lastChild);
	}

	
	
	//add days to dropDownDay
	var docFrag = document.createDocumentFragment();
	for (var i = 1; i <= numOfDays; i++)
	{
		var number;
		//if day is less than 10 (1 digit), add 0 before it to make it 2 digits and avoid sql query error
		if (i.toString().length === 1)
		{
			number = "0" + i.toString();
		}
		else
		{
			number = i;
		}
		//add a new day option to the dropdown var
		docFrag.appendChild(new Option(number, number));
	}

	//add all days to dropdown
	var select = document.getElementById("dropDownDay");
	select.appendChild(docFrag);
}



//add year options based on current year. add only this year and next year.
function refreshYears()
{
	"use strict";

	var currentYear = new Date().getFullYear();
	var docFrag = document.createDocumentFragment();
	for (var i = currentYear; i <= currentYear + 1; i++)
	{
		docFrag.appendChild(new Option(i, i));
	}

	var select = document.getElementById("dropDownYear");
	select.appendChild(docFrag);
}


//adjust sizes when window is resized
window.onresize = function() {
	"use strict";
	
	optimizeLayout();
};


function navigateTo(site) {
	window.location.href = site;
	
}

//animate specified control with specified animation and remove any invisible classes
function animateControl(control, animation, setInvisible)
{
	"use strict";
	
	if (setInvisible)
	{
		//add the animated class and the specified animation class. when animation is finished, remove the animated class and remove the specified animation class
		$(control.toString()).addClass(' animated ' + animation.toString()).one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
	    $(this).removeClass('animated').removeClass(animation);
		//add the invisiblity class
		$(control.toString()).addClass(' invisible');	
	    });
	}
	else
	{
		//remove the invisiblity class if there
		$(control.toString()).removeClass('invisible');	
		//add the animated class and the specified animation class. when animation is finished, remove the animated class and remove the specified animation class
		$(control.toString()).addClass(' animated ' + animation.toString()).one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
	    $(this).removeClass('animated').removeClass(animation);
	    });
	}
}

var isMenuOpen = false;

function showMobileMenu()
{
	if (!isMenuOpen)
	{
		animateControl("#mobileMenuBackground", "fadeInLeft", false);
		isMenuOpen = true;
		setTimeout(function() {
			$("#btnShowMenu").prependTo("#mobileMenu");
			$("#btnShowMenu").css("float", "none");
		}, 800);
	}
	else
	{
		animateControl("#mobileMenuBackground", "fadeOutLeft", true);
		isMenuOpen = false;
		setTimeout(function() {
			$("#btnShowMenu").prependTo("#containerHeader");
			$("#btnShowMenu").css("float", "left");
		}, 800);
	}
}

window.onclick = function(event)
{
	if (event.target == document.getElementById("mobileMenuBackground"))
	{
		showMobileMenu();
	}
}


function optimizeLayout()
{
		//adjust padding of main based on height of fixed header and adjust sizes
	$('#headerTitle').css('top', ("-" + parseInt($('#containerHeader').height()) * 0.36).toString() + "px");
	$('#headerLogo').css('height', parseInt($('#containerHeader').height()));
	$('#headerLogo').css('width', parseInt($('#containerHeader').height()));
	$('#btnShowMenu').css('height', parseInt($('#headerTitle').height()));
	$('#btnShowMenu').css('width', parseInt($('#headerTitle').height()));
	$('#main').css('height', 'initial');
	$('#navbar').css('top', ("-" + parseInt($('#containerHeader').height()) * 0.36).toString() + "px");
	
	if (isMobileDevice)
	{
		$('#main').css('width', window.innerWidth.toString() + "px");
		$('#txtTitle').css('width', '85%');
		$('#txtTeacherName').css('width', '85%');
		$('#txtLocation').css('width', '85%');
		$('#dropDownMonth').css('width', '22%');
		$('#dropDownDay').css('width', '22%');
		$('#dropDownYear').css('width', '22%');
		$('#dropDownSubject').css('width', '85%');
		$('#txtContent').css('width', '85%');
	}
	else
	{

	}
}