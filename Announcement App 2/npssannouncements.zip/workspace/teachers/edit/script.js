/********************************
 **  Announcement Creator       ** 
 **                             **
 ** Mihir lad			       **
 ** ICS3U                       **
 ** Ver 1.0 - October 18, 2016  **
 ********************************/

/*global getCookie optimizeGeneralLayout animateControl generalLoad $ showModalAlertOkOnly showModalAlertYesNo closeModal isMobileDevice*/

var title, content, teacherName, subject, deadlineDate, deadlineTime, target, place, deadline;
var storedAnnouncement;
var presetList = [ ];
var subjectList = [ ];
var announcement;
var presetIndexToRemove;
var maxDays = 31;
var name;

function onLoad()
{
	"use strict";
	
	document.getElementById("txtTeacherName").value = getCookie("name");
	generalLoad();

	refreshYears();
	window.setTimeout(animateControl, 800, '#main', 'slideInDown', false);
	getPresets();
	getSubjectList();
	
	if (isMobileDevice)
	{
		$('#txtTitle').css('width', '85%');
		$('#txtTeacherName').css('width', '85%');
		$('#txtLocation').css('width', '85%');
		$('#dropDownMonth').css('width', '22%');
		$('#txtDeadlineDay').css('width', '22%');
		$('#dropDownYear').css('width', '22%');
		$('#dropDownSubject').css('width', '85%');
		$('#txtContent').css('width', '85%');
	}


	document.getElementById("txtDeadlineDay").addEventListener("keydown", function(event)
	{
		if (filterNumberedInput(document.getElementById("txtDeadlineDay").value, event.keyCode, 1, maxDays)) event.preventDefault();
	});
	
	
	document.getElementById("txtDeadlineHour").addEventListener("keydown", function(event)
	{
		if (filterNumberedInput(document.getElementById("txtDeadlineHour").value, event.keyCode, 1, 12)) event.preventDefault();
	});


	document.getElementById("txtDeadlineMinute").addEventListener("keydown", function(event)
	{
		if (filterNumberedInput(document.getElementById("txtDeadlineMinute").value, event.keyCode, 1, 59)) event.preventDefault();
	});

	
	storedAnnouncement = JSON.parse(localStorage.getItem("announcement"));
	
	$('#txtTitle').val(storedAnnouncement.title);
	$('#txtTeacherName').val(storedAnnouncement.teacherName);
	$('#txtLocation').val(storedAnnouncement.location);
	$('#dropDownTarget').val(storedAnnouncement.target);
	$('#txtContent').val(storedAnnouncement.content);
	
	
	
	if (storedAnnouncement.deadline != "0000-00-00 00:00:00")
	{
		if (parseInt(storedAnnouncement.deadline.substr(11, 2)) > 12 )
		{
			document.getElementById("txtDeadlineHour").value = parseInt(storedAnnouncement.deadline.substr(11, 2)) - 12;
			document.getElementById("dropDownDeadlinePeriod").selectedIndex = getIndexFromValue("PM", "dropDownDeadlinePeriod");
		}
		else
		{ 
			document.getElementById("txtDeadlineHour").value = storedAnnouncement.deadline.substr(11, 2);
		}
		
		document.getElementById("dropDownYear").selectedIndex = getIndexFromValue(storedAnnouncement.deadline.substr(0, 4), "dropDownYear");
		document.getElementById('dropDownMonth').selectedIndex = parseInt(storedAnnouncement.deadline.substr(5, 2));
		refreshDays();
		document.getElementById('txtDeadlineDay').value = parseInt(storedAnnouncement.deadline.substr(8, 2));
		document.getElementById("txtDeadlineMinute").value = storedAnnouncement.deadline.substr(14, 2);
	}
}


function filterNumberedInput(value, keyPressed, min, max)
{
	var blockInput = false;
	
	if (keyPressed >= 48 && keyPressed <= 57)
	{
		var number = event.keyCode - 48;
		
		if (value.toString() == "0" && number == 0)
		{
			blockInput = true;	
		}
		
		if (value.toString().length == max.length)
		{
			blockInput = true;
		}
		
		if (isNaN(value)) value = 0;
		if (parseInt(value.toString() + number.toString()) <= max)
		{

		}
		else
		{
			blockInput = true;
		}
		
		if (value.match(window.getSelection()))
		{
			value = value.replace(window.getSelection().toString(), "");
			if (parseInt(value.toString() + number.toString()) <= max)
			{
				blockInput = false;	
			}

		}
		else if (keyPressed == 8) {}
		else
		{
			blockInput = true;
		}
	return blockInput;
	}
}




function makeTwoDigits(number)
{
	if (number.toString().length == 1) return "0" + number.toString();
	else return number;
}

//save dataa
function saveData()
{
	"use strict";

	var deadlineMonth = document.getElementById("dropDownMonth").selectedIndex;
	var deadlineDay = document.getElementById("txtDeadlineDay").value;
	var deadlineYear = document.getElementById("dropDownYear").value;
	var deadlineHour = document.getElementById("txtDeadlineHour").value;
	var deadlineMinute = document.getElementById("txtDeadlineMinute").value;
	var deadlinePeriod = document.getElementById("dropDownDeadlinePeriod").value;
	

	//get announcement details from textboxes
	title = document.getElementById("txtTitle").value;
	content = document.getElementById("txtContent").value;
	teacherName = document.getElementById("txtTeacherName").value;
	place = document.getElementById("txtLocation").value;
	subject = document.getElementById("dropDownSubject").value;
	target = document.getElementById("dropDownTarget").value;
	
	
	var validAnnouncementFormat = true;

	if (deadlinePeriod == "PM") deadlineHour = parseInt(deadlineHour, 10) + 12;

	//if month is a digit, add zero before it to make it 2 digits to avoid errors in sql query
	deadlineMonth = makeTwoDigits(deadlineMonth);
	deadlineDay = makeTwoDigits(deadlineDay);
	deadlineHour = makeTwoDigits(deadlineHour);
	deadlineMinute = makeTwoDigits(deadlineMinute);


	if (title.trim() == "")
	{
		validAnnouncementFormat = false;
		showModalAlertOkOnly("Error!", "Please enter a valid title for the announcement.");
	}

	if (deadlineDate == null && deadlineHour == "" && deadlineMinute == "")
	{
		deadlineDate = new Date();
		deadlineYear = deadlineDate.toLocaleDateString().substr(6, 4);
		deadlineMonth = deadlineDate.toLocaleDateString().substr(0, 2);
		deadlineDay = deadlineDate.toLocaleDateString().substr(3, 2);
	}
	
	//get announcement deadline from dropdown and ensure valid selections
	if (deadlineYear != "Year" && deadlineDay != "" && deadlineMonth != "Month")
	{
		deadlineDate = deadlineYear.toString() + "-" + deadlineMonth.toString() + "-" + deadlineDay.toString();
	}
	else if (deadlineYear == "Year" && deadlineMonth == "Month" && deadlineDay == "")
	{
		deadlineDate = "";
	}
	if (deadlineHour == "" && deadlineMinute == "")
	{
		deadlineTime = "";
	}
	else if(deadlineHour != "" && deadlineMinute != "")
	{
		deadlineTime = deadlineHour.toString() + ":" + deadlineMinute.toString() + ":00";
	}
	else
	{
		showModalAlertOkOnly("Error", "Please select a valid deadline or keep deadline blank.")
		validAnnouncementFormat = false;
	}

	
	if (deadlineTime == null) deadlineTime = "";
	
	deadline = deadlineDate.toString() + " " + deadlineTime.toString();

	if (validAnnouncementFormat)
	{
		sendRemoveRequest();
	}
}



//send post request to php script with announcement details
function sendAnnouncementToDatabase()
{
	"use strict";

	$.ajax(
	{
		url: "/teachers/php/addAnnouncement.php",
		type: 'POST',
		data:
		{
			"title": title.toString(),
			"subject": subject.toString(),
			"content": content.toString(),
			"location": place.toString(),
			"deadline": deadline.toString(),
			"target": target.toString()
		},
		//alert response from php
		success: function(response)
		{
			if (!response.toLowerCase().match("error"))
			{
				$("#modalSuccess").css("display", "block");
			}
			else
			{
				showModalAlertOkOnly("Failure Adding Announcement", response);
			}
		}
	});
}


function sendPresetToDatabase()
{
	"use strict";

	$.ajax(
	{
		url: "/teachers/php/addPreset.php",
		type: 'POST',
		data:
		{
			"title": title.toString(),
			"subject": subject.toString(),
			"content": content.toString(),
			"location": place.toString(),
			"deadline": deadline.toString(),
			"target": target.toString()
		},
		//alert response from php
		success: function(response)
		{
			if (!response.toLowerCase().match("error"))
			{
				showModalAlertOkOnly("Preset Added Successfully!", "");
				getPresets();
				clearForm();
				showModalAlertYesNo("View Announcements?", "Would you like to view the announcements?", function() { window.location.href = "/teachers/view" });
			}
			else
			{
				showModalAlertOkOnly("Failure Adding Announcement", response);
			}
		}
	});
}



//refresh the number of days in the dropdown based on which month it is. e.g. January: add 31 days, April: add 30 days
function refreshDays()
{
	"use strict";

	var index = document.getElementById("dropDownMonth").selectedIndex;

	maxDays = 30;

	//if index of month selected is a month with 31 days, set numOfDays to 31
	if (index === 1 || index === 3 || index === 5 || index === 7 || index === 8 || index === 10 || index === 12)
	{
		maxDays = 31;
	}
	
}




//add year options based on current year. add only this year and next year.
function refreshYears()
{
	"use strict";

	var currentYear = new Date().getFullYear();
	var docFrag = document.createDocumentFragment();
	for (var i = currentYear; i <= currentYear + 1; i++)
	{
		docFrag.appendChild(new Option(i, i));
	}

	var select = document.getElementById("dropDownYear");
	select.appendChild(docFrag);
}


//adjust sizes when window is resized
window.onresize = function() {
	"use strict";
	
	optimizeGeneralLayout();
};


function getPresets()
{
	$("#listGroupPresets").empty();
	$.ajax(
	{
		url: "/teachers/php/getPresets.php",
		type: "GET",
		data: {
			"teacherName": $("#txtTeacherName").val()
		},
		success: function(response)
		{
			presetList = JSON.parse(response);
			
			for (var i = 0; i < presetList.length; i++)
			{
				addPresetToList(i);
			}
		}
	});
}


function addPresetToList(num)
{
	var htmlString = "<a href='#' onclick='presetClicked(" + num.toString() + ");' class='list-group-item' id='presetItem" + num.toString() + "'>" + presetList[num].title + 
		"<span onclick='showPresetDeletionModal(" + num.toString() + ");' class='btnPresetRemove'>x</span>" +
	"</a>";
	
	$("#listGroupPresets").append(htmlString);
}

function presetClicked(num)
{
	
	if ($("#presetItem" + num.toString()).hasClass("active"))
	{
		$("#presetItem" + num.toString()).removeClass("active");
		clearForm();
	}
	else
	{
		clearForm();
		
		document.getElementById("txtTitle").value = presetList[num].title;
		document.getElementById("txtContent").value = presetList[num].content;
		document.getElementById("txtTeacherName").value = presetList[num].teacherName;
		document.getElementById("txtLocation").value = presetList[num].location;
		document.getElementById("dropDownSubject").value = presetList[num].subjectOf;
		document.getElementById("dropDownTarget").value = presetList[num].target;
		
		for (var i = 0; i < presetList.length; i++)
		{
			$("#presetItem" + i.toString()).removeClass("active");
		}
		
		$("#presetItem" + num.toString()).addClass("active");
	}
}


function clearForm()
{
	document.getElementById("txtTitle").value = "";
	document.getElementById("txtContent").value = "";
	document.getElementById("txtTeacherName").value = "";
	document.getElementById("txtLocation").value = "";
	document.getElementById("dropDownSubject").value = "General";
	document.getElementById("dropDownTarget").value = "All";
	document.getElementById("dropDownMonth").value = "Month";
	document.getElementById("dropDownYear").value = "Year";
	document.getElementById("txtDeadlineHour").value = "";
	document.getElementById("txtDeadlineMinute").value = "";
	document.getElementById("txtDeadlineDay").value = "";
}



function showPresetDeletionModal(num)
{
	showModalAlertYesNo("Remove Preset", "Are you sure you want to remove <b>" + presetList[num].title + "</b>?", removePreset);
	$("#presetName").text(presetList[num].title);
	presetIndexToRemove = num;
}


function removePreset()
{
	$.ajax({
		url: "/teachers/php/removePreset.php",
		type: "POST",
		data:
		{
			"id": presetList[presetIndexToRemove].announcementID
		},
		success: function(response) {
			if (response.toLowerCase().match("error"))
			{
				closeModal();
				showModalAlertOkOnly("Error Deleting Preset!", response);
			}
			else
			{
				closeModal();
				showModalAlertOkOnly("Successfully Removed Preset!", response);
			}
			getPresets();
		}
	});
}


function intellisense()
{
	var title = document.getElementById("txtTitle").value;
	
	for (var i = 0; i < subjectList.length; i++)
	{
		if (title.toLowerCase().match(subjectList[i].toLowerCase()))
		{
			document.getElementById("dropDownSubject").selectedIndex = i;
			document.getElementById("dropDownTarget").selectedIndex = 1;
		}
	}
	
	if (title.toLowerCase().match("boy"))
	{
		document.getElementById("dropDownTarget").selectedIndex = 3;
	}
	else if (title.toLowerCase().match("girl"))
	{
		document.getElementById("dropDownTarget").selectedIndex = 4;
	}
}

function getSubjectList()
{
	$.ajax({
		url: "/teachers/php/getSubjects.php",
		type: "GET",
		success: function(response)
		{
			subjectList = JSON.parse(response);
			subjectList.push("General");
			subjectList.reverse();
			for (var i = 0; i < subjectList.length; i++) {
				var option = document.createElement("option");
				option.value = subjectList[i];
				option.innerHTML = subjectList[i];
				document.getElementById("dropDownSubject").appendChild(option);
			}
			document.getElementById('dropDownSubject').value = storedAnnouncement.subjectOf;
		}
	});
}

function setDeadlineToday()
{
	var today = new Date();
	document.getElementById("dropDownYear").selectedIndex = getIndexFromValue(today.toLocaleDateString().substr(6, 4), "dropDownYear");
	document.getElementById("dropDownMonth").selectedIndex = today.toLocaleDateString().substr(0, 2);
	document.getElementById("txtDeadlineDay").value = today.toLocaleDateString().substr(3, 2);
}



function sendRemoveRequest(announcement)
{
	$.ajax({
		url: "/teachers/php/deleteAnnouncement.php",
		type: "POST",
		data:
		{
			"id": storedAnnouncement.announcementID	
		},
		success: function(response)
		{
			if (!response.toLowerCase().match("error"))
			{
				showModalAlertOkOnly("Removed Announcement Successfully!", "", function(){ sendAnnouncementToDatabase(announcement) });
			}
			else
			{
				showModalAlertOkOnly("Failure Adding Announcement", response, function(){});
			}
		}
	})
}