/********************************
**  Announcement View       ** 
**                             **
** Mihir lad			       **
** ICS3U                       **
** Ver 1.0 - October 18, 2016  **
********************************/

/*global optimizeGeneralLayout animateControl*/

var announcementList;
var filteredList;
var isMobileDevice = false;
var $;

function onLoad()
{
	"use strict";
	
	isMobileDevice = (/Android|SamsungBrowser|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) ? true : false;

	
	window.setTimeout(animateControl, 400, '#main','slideInDown');	//get announcements 1 second after the page loads
	window.setTimeout(getAnnouncements, 1000);
	window.setTimeout(animateControl, 1000, '#btnToggleView', 'slideInDown');

	
	if (isMobileDevice)
	{
		$('#main').css('width', '100%');
		$('#btnShowMenu').removeClass('invisible');
		$('#navbar').addClass(" invisible");
		$('#headerLogo').addClass(' invisible');
		$('#containerHeader').addClass(' containerHeaderMobile');
		$('#headerTitle').addClass(' headerTitleMobile');
		$('#btnShowMenu').addClass(' btnShowMenuMobile');
	}
	else
	{
		$('#main').css('min-width', (parseInt($(window).width()) * 0.3).toString() + "px");
		$('#main').css('width', parseInt($(window).width() * 0.6, 10));
		$('#main').css('padding-top', (parseInt($("#containerHeader").height()) * 1.5).toString() + "px");
	}
	optimizeGeneralLayout();
}

// get announcements from php script on server
function getAnnouncements()
{	
	"use strict";
	
     $.ajax({
        url: 'getStudentAnnouncements.php',
        type: 'GET',
        success: function(response){
			announcementList = JSON.parse(response);
			announcementList.reverse();// reverse array to make newer announcements come first
			getRelevantAnnouncements();
			addAnnouncementCards(announcementList); 
			addAnnouncementsToTable();
			addSubjectFilterOptions();
			addTeacherFilterOptions();
       }
   });
}


function getRelevantAnnouncements()
{
	var subjectSettings = localStorage.getItem("subjectSettings");
	var teacherSettings = localStorage.getItem("teacherSettings");
	var targetSettings = localStorage.getItem("targetSettings");
	
	
	if (subjectSettings == null) subjectSettings = [ ];
	if (teacherSettings == null) teacherSettings = [ ];
	if (targetSettings == null) targetSettings = [ "All", "All Students", "Male Students", "Female Students" ];
	
	
	var filteredAnnouncementList = [ ];
	
	for (var i = 0; i < announcementList.length; i++)
	{
		if ((subjectSettings.indexOf(announcementList[i].subjectOf) != -1) && (targetSettings.indexOf(announcementList[i].target) != -1 || announcementList[i].target == ("All Students") || announcementList[i].target == ("All")))
		{
			filteredAnnouncementList.push(announcementList[i]);
		}
		else if ((teacherSettings.indexOf(announcementList[i].teacherName) != -1) && (targetSettings.indexOf(announcementList[i].target) != -1 || announcementList[i].target == ("All Students") || announcementList[i].target == ("All")))
		{
			filteredAnnouncementList.push(announcementList[i]);
		}
	}
	announcementList = filteredAnnouncementList;
}


function addSubjectFilterOptions()
{
	var subjectList = [ ];
	var teacher = $('#dropDownTeacherFilter').val();
/*	var optionList = [ ]; // document.getElementById('dropDownSubjectFilter').options;

	//$('#dropDownSubjectFilter').empty();

	$("#dropDownSubjectFilter").each(function()
	{
		optionList.push($(this).val());
	});
	
	
	for (var i = 0; i < optionList.length; i++) {
		alert(optionList[i]);
	} 
	
	var mainOption = document.createElement('Option');
	mainOption.innerHTML = "All Subjects";
	$('#dropDownSubjectFilter').append(mainOption); */
	
	for (var i = 0; i < announcementList.length; i++)
	{
		var isSubjectAdded = false;
		for (var s = 0; s < subjectList.length; s++)
		{
			if (subjectList[s] == announcementList[i].subjectOf.toString())
			{
				isSubjectAdded = true;
			}
		}
		
		if (!isSubjectAdded)
		{
			if (teacher == "All Teachers")
			{
				subjectList.push(announcementList[i].subjectOf.toString());
				isSubjectAdded = false;	
			}
			else if (teacher == announcementList[i].teacherName)
			{
				subjectList.push(announcementList[i].subjectOf.toString());
				isSubjectAdded = false;	
			}
		}
	}
	
	for (var i = 0; i < subjectList.length; i++)
	{
		var option = document.createElement('Option');
		option.innerHTML = subjectList[i];
		$('#dropDownSubjectFilter').append(option);
	}
}



function addTeacherFilterOptions()
{
	var teacherList = [ ];
	var subject = $('#dropDownSubjectFilter').val();

/*	$('#dropDownTeacherFilter').empty();
	
	var mainOption = document.createElement('Option');
	mainOption.innerHTML = "All Teachers";
	$('#dropDownTeacherFilter').append(mainOption); */
	
	for (var i = 0; i < announcementList.length; i++)
	{
		var isTeacherAdded = false;
		for (var s = 0; s < teacherList.length; s++)
		{
			if (teacherList[s] == announcementList[i].teacherName.toString())
			{
				isTeacherAdded = true;
			}
		}
		
		if (!isTeacherAdded)
		{
			//alert("'" + subject + "'");
			teacherList.push(announcementList[i].teacherName.toString());
			isTeacherAdded = false;
		}
	}
	
	for (var i = 0; i < teacherList.length; i++)
	{
		var option = document.createElement('Option');
		option.innerHTML = teacherList[i];
		$('#dropDownTeacherFilter').append(option);
	}
}



//create all table body, row, and cell nodes with announcement information and add it to table.
function addAnnouncementsToTable()
{
	"use strict";
		
	var tableBody = document.createElement("tbody");
	for (var i = 0; i < announcementList.length; i++)
	{

		var tableRow = document.createElement("tr");
		
		tableRow.id = "announcementRow" + i.toString(); //give each announcement row unique id based on array index
		
		var titleCell = document.createElement("td");
		var subjectCell = document.createElement("td");
		var dateCreatedCell = document.createElement("td");
		var locationCell = document.createElement("td");
		var deadlineCell = document.createElement("td");	
		
		titleCell.innerHTML = announcementList[i].title;
		subjectCell.innerHTML = announcementList[i].subjectOf;
	//	dateCreatedCell.innerHTML = getInformalTime(announcementList[i].timestamp.toString().substring(9,11));
		locationCell.innerHTML = announcementList[i].location;
		deadlineCell.innerHTML = getInformalDateTime(announcementList[i].deadline.toString());
		
		tableRow.appendChild(titleCell);
		tableRow.appendChild(subjectCell);
		
		
	/*	if (!isMobileDevice)
		{
			tableRow.appendChild(dateCreatedCell);
		}*/
		
		tableRow.appendChild(locationCell);
		tableRow.appendChild(deadlineCell);
		
		tableBody.appendChild(tableRow);
	}
	
	document.getElementById("tableAnnouncements").appendChild(tableBody);
	addClickEvents();
}

//get time such as 2 days ago instead of actual date
function getInformalDateTime(date, typeOfDate)
{
	"use strict";
	
	//get the difference in days between today and the date given as a parameter
	var timeDifference = (parseInt(new Date().getDate()) - parseInt(date.substr(8,2)));
	
	//find out if the difference is positive (in the past) or negative (in the future)
	var isDifferencePositive = (timeDifference > 0 ? true : false);
		switch (Math.abs(parseInt(timeDifference)))
		{
			case 0:
				if (typeOfDate != "timestamp")
				{
					return "Today";
				}
				else
				{
					return get12HourTime(date.substr(11, 5));
				}
			case 1:
				//return difference in days based on whether difference is positive or negative
				//alert(date.substr(8,2));
				return (isDifferencePositive ? "Yesterday" : "Tomorrow"); 
			case 2:
				return (isDifferencePositive ? "2 Days Ago" : "In 2 Days" );
			case 3:
				return (isDifferencePositive ? "3 Days Ago" : "In 3 Days" );
			case 4:
				return (isDifferencePositive ? "4 Days Ago" : "In 4 Days" );
			case 5:
				return (isDifferencePositive ? "5 Days Ago" : "In 5 Days" );
			case 6:
				return (isDifferencePositive ? "6 Days Ago" : "In 6 Days" );
			case 7:
				return (isDifferencePositive ? "1 Week Ago" : "In 1 Week" );
			default:	
		}
		
		//if the difference is greater than 1 week
		if (1 < (timeDifference / 7) <= 3)
		{
			return parseInt((timeDifference / 7)).toString() + " Weeks Ago";
		}
		else if (3 < (timeDifference / 7)  < 52)
		{
			//alert(timeDifference);
			return parseInt(((timeDifference / 7) / 4)).toString() + " Months Ago";
		}

}


function get12HourTime(time)
{
	var date = new Date();
	
	date.setHours(time.substr(0,2));
	date.setMinutes(time.substr(3,2));
	
	var dateArray = date.toLocaleTimeString().split(':', 3);

	var dateString = dateArray[0].toString() + ":" + dateArray[1].toString();
	dateString = dateString + ((11 < date.getHours() < 24) ? " PM" : " AM");
	
	return dateString;
}

//go through every announcement and add announcement cards
function addAnnouncementCards(list)
{
	"use strict";
	
	filteredList = list;
	$("#containerAnnouncements").empty();
	
	for (var i = 0; i < list.length; i++)
	{
		createNewCard(list[i], i);
	}
	
	$('#numOfAnnouncementsFound').text((list.length).toString() + " Announcements Found");
}

//create the card html and add it to the #main div. add announcement details of specified announcement within their particular areas in the html.
function createNewCard(announcement, num)
{
	"use strict";
	
	var removeDeadline = false;
	
	if (announcement.deadline == "0000-00-00")
	{
		removeDeadline = true;
	}
	
	//alert(announcement.timestamp);
	if (removeDeadline)
	{
		var cardHtml = "<div class='announcementBox invisible' id='announcementBox" + num + "'>" +
                "<h3 class='announcementTitle'>" + announcement.title + "</h3>" +
                "<p class='announcementDateTime'>" + getInformalDateTime(announcement.timestamp, "timestamp") + "</p>" +
                "<div class='mainProperties'>" +
                    "<div class='announcementHeader lblSubject'>Subject: </div> <div class='announcementValue announcementSubject'>" + announcement.subjectOf + 				
				 	"</div>" +
                    "<div class='announcementHeader lblTeacher'>Teacher: </div> <div class='announcementValue announcementTeacherName'>" + announcement.teacherName +
				  "</div>" +
                "</div>" + 
                "<div class='announcementValue announcementContent'>" + announcement.content + "</div>" +
            "</div>";
	}
	else
	{
		var cardHtml = "<div class='announcementBox invisible' id='announcementBox" + num + "'>" +
                "<h3 class='announcementTitle'>" + announcement.title + "</h3>" +
                "<p class='announcementDateTime'>" + getInformalDateTime(announcement.timestamp, "timestamp") + "</p>" +
                "<div class='mainProperties'>" +
                    "<div class='announcementHeader lblSubject'>Subject: </div> <div class='announcementValue announcementSubject'>" + announcement.subjectOf + 				
				 	"</div>" +
                    "<div class='announcementHeader lblTeacher'>Teacher: </div> <div class='announcementValue announcementTeacherName'>" + announcement.teacherName +
				  "</div>" +
                    "<div class='announcementHeader lblDeadline'>Deadline: </div> <div class='announcementValue announcementDeadline'>" + announcement.deadline+		
				   "</div>" +
                "</div>" + 
                "<div class='announcementValue announcementContent'>" + announcement.content + "</div>" +
            "</div>";	
	}
	

	$('#containerAnnouncements').append(cardHtml);
	animateControl('#announcementBox' + num.toString(), "slideInDown", false);
}

//add a click event to each table row to bring up more information
function addClickEvents()
{
	"use strict";
	
	for(var i = 0; i < announcementList.length; i++)
	{
		$('#announcementRow' + i.toString()).attr('onClick', 'onRowClick(' + i.toString() + ');');
	}
}

function onRowClick(i)
{
	"use strict";
	
	//show modal with selected announcement's content
	$('#modal').css('display', 'block');
	$('#modalAnnouncementContent').text(announcementList[i].content);
	$('#modalAnnouncementSubject').text(announcementList[i].subjectOf);
	$('#modalAnnouncementTitle').text(announcementList[i].title);
	$('#modalAnnouncementTeacherName').text(announcementList[i].teacherName);
	
	var timestampDate = announcementList[i].timestamp.toString().substring(0, 10);
	var timestampTime = announcementList[i].timestamp.toString().substring(11, 16);
		
	var date = new Date(parseInt(timestampDate.substring(0,4)), parseInt(timestampDate.substring(5,7)), parseInt(timestampDate.substring(9,11)));
	
	$('#modalAnnouncementDateCreated').empty();
	$('#modalAnnouncementDateCreated').append("<span style='font-weight: bold;'>Date Created: </span>" + getDateString(date));
	
	//if deadline is "0000-00-00", make the deadline blank
	if(announcementList[i].deadline.toString() !== "0000-00-00")
	{
		$('#modalAnnouncementDeadline').text(announcementList[i].deadline);
	}
	else 
	{
		$('#modalAnnouncementDeadline').text('');
	}


}


function getDateString(date)
{
	"use strict";
	
	var months = [ "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" ];
	var days = [ "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday" ];
	
	var dateString = days[date.getDay()].toString() + ", " + months[date.getMonth() - 1].toString() + " " + date.getDate().toString() + ", " + date.getFullYear().toString();
	return dateString.toString();
}


function showTable()
{
	"use strict";
	
	//change appearance and function of view button
	$('#btnToggleView').css('background-image', 'url(/images/cardview.png)');	
	$('#btnToggleView').attr('onClick', 'showCards();');
	$('#btnToggleView').addClass(' invisible');
	$('#title').addClass(' invisible');
	
	//add announcement cards
	for(var i = 0; i < announcementList.length; i++)
	{
		$('#announcementBox' + i.toString()).addClass(' invisible');
	}
	
	animateControl('#tableAnnouncements', 'slideInDown', false);
	window.setTimeout(animateControl, 1000, '#title', 'slideInDown');
	window.setTimeout(animateControl, 1000, '#btnToggleView', 'slideInRight');
}

function showCards()
{
	"use strict";
	
	//change appearance and function of view button
	$('#btnToggleView').css('background-image', 'url(/images/tableview.png)');
	$('#btnToggleView').attr('onClick', 'showTable();');
	
	$('#tableAnnouncements').addClass(' invisible');
	
	
	for(var i = 0; i < announcementList.length; i++)
	{
		animateControl('#announcementBox' + i.toString(), 'slideInDown', false);
	}
}



//close the modal by hiding it
function closeModal() {
	"use strict";
	
	$('#modal').css('display', 'none');
}


function closeSortDialog()
{
	$('#sortDialog').css('top', "-" + parseInt($('#sortDialog').height()).toString() + "px");
	$('#sortDialog').addClass(' animated fadeInUp').one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
	   $(this).removeClass('animated').removeClass('fadeInUp');
	$('#sortDialog').addClass(' invisible');
	$('#sortDialog').css('top', '');
	});
}

//if user clicks off the screen, close the modal by hiding it
window.onclick = function(event) {
	"use strict";
	
	if(event.target === document.getElementById('modal'))
	{
		closeModal();
	}
	else if(event.target === document.getElementById('sortDialog'))
	{
		closeSortDialog();
	}
};


//adjust size of logo according to screen size
window.onresize = function() {
	optimizeGeneralLayout();
	
};



function showFilterDialog()
{
	animateControl('#sortDialog', 'fadeInDown')
}


function filterAnnouncements()
{
	filteredList = [ ];
	var count = 0;
	

	$('#containerAnnouncements').empty();
	
	var selectedSubject = $('#dropDownSubjectFilter').val();
	var selectedTeacher = $('#dropDownTeacherFilter').val();
	var selectedTarget = $('#dropDownTargetFilter').val();
	
	
	for (var i = 0; i < announcementList.length; i++)
	{
		var hasMatchingSubject = false;
		var hasMatchingTeacher = false;
		var hasMatchingTarget = false;
		
		if (announcementList[i].subjectOf.match(selectedSubject))
		{
			hasMatchingSubject = true;
		}
		else
		{
			hasMatchingSubject = false;
		}
		
		if (announcementList[i].teacherName.match(selectedTeacher))
		{
			hasMatchingTeacher = true;
		}
		else
		{
			hasMatchingTeacher = false;
		}
		
		if (announcementList[i].target.match(selectedTarget))
		{
			hasMatchingTarget = true;
		}
		else
		{
			hasMatchingTarget = false;
		}
		
		
		hasMatchingSubject = (selectedSubject == "All Subjects") ? true : hasMatchingSubject;
		hasMatchingTeacher = (selectedTeacher == "All Teachers") ? true : hasMatchingTeacher;
		hasMatchingTarget = (selectedTarget == "All") ? true : hasMatchingTarget;
		hasMatchingTarget = (selectedTarget == "All Students") ? true : hasMatchingTarget;
		
		
		if (hasMatchingSubject && hasMatchingTeacher && hasMatchingTarget)
		{
			filteredList.push(announcementList[i]);
			count++;
		}
		
		addAnnouncementCards(filteredList);
	}
	closeSortDialog();
	$('#numOfAnnouncementsFound').text((count).toString() + " Announcements Found");
}


function search()
{
	var searchString = $('#txtSearch').val().toLowerCase();
	var count = 0
	
	for (var t = 0; t < filteredList.length; t++)
	{
		$('#announcementBox' + t.toString()).addClass(' invisible');
	}
	
	for (var i = 0; i < filteredList.length; i++)
	{
		var isMatchFound = false;
		
		isMatchFound = ((filteredList[i].title.toLowerCase().match(searchString)) ? true : isMatchFound);
		isMatchFound = ((filteredList[i].teacherName.toLowerCase().match(searchString)) ? true : isMatchFound);
		isMatchFound = ((filteredList[i].subjectOf.toLowerCase().match(searchString)) ? true : isMatchFound);
		isMatchFound = ((filteredList[i].deadline.toString().toLowerCase().match(searchString)) ? true : isMatchFound);
		isMatchFound = ((filteredList[i].timestamp.toString().toLowerCase().match(searchString)) ? true : isMatchFound);
		isMatchFound = ((filteredList[i].content.toLowerCase().match(searchString)) ? true : isMatchFound);
		isMatchFound = ((filteredList[i].location.toLowerCase().match(searchString)) ? true : isMatchFound);
		
		if (isMatchFound)
		{
			animateControl('#announcementBox' + i.toString(), 'fadeInDown', false);
			count++;
		}
	}
	
	$('#numOfAnnouncementsFound').text((count).toString() + " Announcements Found");
}