

/*global $ closeSortDialog*/
var isMobileDevice = false;
var portraitOrientation = false;


function navigateTo(site) {
	window.location.href = site;
	
}

//animate specified control with specified animation and remove any invisible classes
function animateControl(control, animation, setInvisible)
{
	"use strict";
	
	if (setInvisible)
	{
		//add the animated class and the specified animation class. when animation is finished, remove the animated class and remove the specified animation class
		$(control.toString()).addClass(' animated ' + animation.toString()).one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
	    $(this).removeClass('animated').removeClass(animation);
		//add the invisiblity class
		$(control.toString()).addClass(' invisible');	
	    });
	}
	else
	{
		//remove the invisiblity class if there
		$(control.toString()).removeClass('invisible');	
		//add the animated class and the specified animation class. when animation is finished, remove the animated class and remove the specified animation class
		$(control.toString()).addClass(' animated ' + animation.toString()).one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
	    $(this).removeClass('animated').removeClass(animation);
	    });
	}
}

var isMenuOpen = false;

function showMobileMenu()
{
	if ($("#mobileMenuBackground").hasClass("invisible"))
	{
		animateControl("#mobileMenuBackground", "fadeInLeft", false);
		$("#btnShowMenu").prependTo("#mobileMenu");
		$("#btnShowMenu").css("float", "none");
		$("#btnShowMenu").css("margin-left", "5%");
		isMenuOpen = true;
	}
	else
	{
		animateControl("#mobileMenuBackground", "fadeOutLeft", true);
		$("#btnShowMenu").prependTo("#containerHeader");
		$("#btnShowMenu").css("float", "left");
		$("#btnShowMenu").css("margin-left", "");
		isMenuOpen = false;

	}
}

window.addEventListener("click", function(event)
{
	if (event.target == document.getElementById("mobileMenuBackground"))
	{
		showMobileMenu();
	}
	
	if (document.getElementById("profileOptions") != null)
	{
		if (event.target != document.getElementById("profileOptions") && event.target != document.getElementById("btnPreferences") && event.target != document.getElementById("btnLogOut") )
		{
			if (event.target == document.getElementById("navbarProfilePicture") && $("#profileOptions").hasClass("invisible"))
			{
				$("#profileOptions").removeClass("invisible");
			}
			else
			{
				$("#profileOptions").addClass("invisible");
			}
		}
	}
	
	if (document.getElementById("sortDialog") != null && event.target != document.getElementById("sortDialogContent") && event.target.parentNode != document.getElementById("sortDialogContent") && event.target.parentNode.parentNode != document.getElementById("sortDialogContent") && event.target.parentNode.parentNode.parentNode != document.getElementById("sortDialogContent") && event.target.parentNode.parentNode.parentNode.parentNode != document.getElementById("sortDialogContent"))
	{
		if (!$("#sortDialog").hasClass("invisible") && event.target != document.getElementById("btnSort"))
		{
			closeSortDialog();
		}
	}
});


function optimizeGeneralLayout()
{
	portraitOrientation = (parseInt(window.innerWidth) < parseInt(window.innerHeight)) ? true : false;

	//adjust padding of main based on height of fixed header and adjust sizes
	$('#headerTitle').css('top', ("-" + parseInt($('#containerHeader').height()) * 0.36).toString() + "px");
	$('#headerLogo').css('height', parseInt($('#headerTitle').height()));
	$('#headerLogo').css('width', parseInt($('#headerTitle').height()));
	$("#containerHeader").css("width", (window.innerWidth).toString() + "px");
	$("#main").css("height", "auto");
//	$('#navbar').css('top', ("-" + parseInt($('#containerHeader').height()) * 0.36).toString() + "px");
	
	if (portraitOrientation && !isMobileDevice)
	{
		$("#headerTitle").css("font-size", "4vh");
	}
	else
	{
	//	$("#headerTitle").css("font-size", "3vh");
	}
	
	if (isMobileDevice || portraitOrientation)
	{
		$('#btnShowMenu').removeClass('invisible');
		$('#navbar').addClass(" invisible");
		$('#headerLogo').addClass(' invisible');
		$('#containerHeader').addClass(' containerHeaderMobile');
		$('#headerTitle').addClass(' headerTitleMobile');
		$('#btnShowMenu').addClass(' btnShowMenuMobile');
		$('#btnShowMenu').css('height', parseInt($('#headerTitleText').height()).toString() + "px");
		$('#btnShowMenu').css('width', parseInt($('#headerTitleText').height()).toString() + "px");
		$('#btnShowMenu').css('max-height', (parseInt(window.outerWidth)*0.1).toString() + "px");
		$('#btnShowMenu').css('max-width', (parseInt(window.outerWidth)*0.1).toString() + "px");
	}
	else
	{
		$('#btnShowMenu').addClass('invisible');
		$('#navbar').removeClass("invisible");
		$('#headerLogo').removeClass('invisible');
		$('#containerHeader').removeClass('containerHeaderMobile');
		$('#headerTitle').removeClass('headerTitleMobile');
		$('#btnShowMenu').removeClass('btnShowMenuMobile');
		$('#main').css('width', parseInt($(window).width() * 0.6, 10));

	}
}


function generalLoad()
{
	isMobileDevice = (/Android|SamsungBrowser|iPhone OS|Version|10.0 Mobile|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) ? true : false;
	portraitOrientation = (parseInt(window.innerWidth) < parseInt(window.innerHeight)) ? true : false;
	
	if (isMobileDevice || portraitOrientation)
	{
		$('#main').css('width', '100%');
		$("#containerHeader").css("width", (window.innerWidth).toString() + "px");
	}
	else
	{
		$('#main').css('min-width', (parseInt($(window).width()) * 0.3).toString() + "px");
		$('#main').css('width', parseInt($(window).width() * 0.6, 10));
		$('#main').css('padding-top', (parseInt($("#containerHeader").height()) * 1.5).toString() + "px");
	}
	
	$("#containerHeader").css("top", "0px");
	$("#main").css("min-height", window.innerHeight);
	optimizeGeneralLayout();
}


window.addEventListener("orientationchange", function() {
	optimizeGeneralLayout();
});


function closeModal()
{
	$(".modal").css("display", "none");
}


var lastScrollPosition = 0;

window.onscroll = function ()
{
	$("#containerHeader").css("position", "fixed");
	
	var scrollPositionDifference = lastScrollPosition - window.pageYOffset;
	var currentY = parseInt($("#containerHeader").css("top"));
	var minY = (parseInt($("#containerHeader").css("height"))*(-1));
	var maxY = 0;
	
	if (scrollPositionDifference > 0)
	{
		//$("#containerHeader").css("position", "fixed");
		//$("#containerHeader").css("top", (0 - lastScrollPosition - window.pageYOffset).toString() + "px");
		if (currentY < 0)
		{
			if (currentY + (scrollPositionDifference*(1)) > 0)
			{
				$("#containerHeader").css("top", "0px");
			}
			else
			{
				$("#containerHeader").css("top", (currentY + (scrollPositionDifference*(1))).toString() + "px");
			}
		}
		
	}
	else if (scrollPositionDifference < 0)
	{
		if (currentY > minY)
		{
			if (currentY + (scrollPositionDifference*(1)) < minY)
			{
				$("#containerHeader").css("top", minY.toString() + "px");
			}
			else
			{
				$("#containerHeader").css("top", (currentY + (scrollPositionDifference*(1))).toString() + "px");
			}
		}
		
	}
	
	lastScrollPosition = window.pageYOffset;
};


window.onresize = function()
{
	optimizeGeneralLayout();
};


function showModalAlertOkOnly(title, body, onClickOk)
{
	$("#modalAlertOkOnlyTitle").text(title);
	$("#modalAlertOkOnlyBody").text(body);
	$("#modalAlertOkOnly").css("display", "block");
	$("#modalAlertOkOnlyBtnOk").bind("click", onClickOk);
}


function showModalAlertYesNo(title, body, onClickYes)
{
	$("#modalAlertYesNoTitle").html(title);
	$("#modalAlertYesNoBody").html(body);
	$("#modalAlertYesNo").css("display", "block");
	$("#modalAlertBtnYes").bind("click", onClickYes);
}


function logOut()
{
	$.ajax(
		{
			url: "/logout.php",
			type: "GET",
			success: function() { window.location.reload(); }
		});
}


function getCookie(name)
{
	var cookieArray = document.cookie.toString().split(';');
	for (var index = 0; index < cookieArray.length; index++)
	{
		if (cookieArray[index].match(name))
		{
			return cookieArray[index].replace(" name=", "").replace("+", " ");
		}
	}
}

function postToPHP(url, data, callbackResponse)
{
	$.ajax(
		{
			url: url,
			type: "POST",
			data: data,
			success: callbackResponse()
		});
}


function getFromPHP(url, data, callbackResponse)
{
	$.ajax(
		{
			url: url,
			type: "GET",
			data: data,
			success: callbackResponse()
		});
}

function getIndexFromValue(value, id)
{
	for (var i = 0; i < document.getElementById(id).options.length; i++)
	{
		if (document.getElementById(id).options[i].value.match(value)) return i;
	}
}

function isAllTextSelected(input)
{
	return (window.getSelection() == input.value);
}