/********************************
**  Announcement Home	       ** 
**                             **
** Mihir lad			       **
** ICS3U                       **
** Ver 1.0 - October 18, 2016  **
********************************/



function onLoad()
{
	"use strict";
	
	$('#main').css('height', '4000px');
	animateControl('#containerHeader', 'slideInLeft');
	window.setTimeout(animateControl, 400, '#main','slideInDown');	//get announcements 1 second after the page loads
	window.setTimeout(getAnnouncements, 1000);
	window.setTimeout(animateControl, 1000, '#btnToggleView', 'slideInDown');
	$('#headerTitle').css('top', ("-" + parseInt($('#containerHeader').height()) * 0.36).toString() + "px");
	$('#headerLogo').css('height', parseInt($('#containerHeader').height()));
	$('#headerLogo').css('width', parseInt($('#containerHeader').height()));
	$('#main').css('width', parseInt($(window).width() * 0.6, 10));
	$('#main').css('height', 'initial');
	$('#navbar').css('top', ("-" + parseInt($('#containerHeader').height()) * 0.36).toString() + "px");
	
	//set padding of main to height of fixed header to avoid it being covered by the header
	$('#main').css('padding-top', parseInt($('#containerHeader').height()));

	if (isMobileDevice())
	{
		$('#main').css('margin-right', "0px");
		$('#main').css('margin-left', "0px");
		$('#containerHeader').css('position', 'relative');
		$('#containerHeader').removeClass('navbar-fixed-top');
		$('#containerHeader').css('width', '100%');
		$('#websiteHeader').css('font-size', '2em');
		$('#main').css('padding-top', '1%');
		$('#main').css('width', '100%');
		$('#containerHeader').css('width', '100%');
		$('#tableHeaderDateCreated').remove();
	}
}


//add animation to control
function animateControl(control, animation)
{
	"use strict";
	
	//remove the invisiblity class if there
	$(control.toString()).removeClass('invisible');	
	//add the animated class and the specified animation class. when animation is finished, remove the animated class and remove the specified animation class
	$(control.toString()).addClass(' animated ' + animation.toString()).one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
      $(this).removeClass('animated').removeClass(animation);
    });
		
}

//if this is not a mobile device and the user scrolls to the top, add the header to navigation bar so it is not hidden by the fixed navigation bar. When the user begins to scroll back down, add the header back to the body.
window.onscroll = function combineHeaderWithNavbar()
{
	"use strict";
	
	if (!isMobileDevice())
	{
		if ($(window).scrollTop() > 65)
		{
			$('#blueHeader').prependTo('body');
		}
		else if ($(window).scrollTop() < 65)
		{
			$('#blueHeader').prependTo('#containerHeader');
		}
		
		$('#main').css('padding-top', ((parseInt($('#containerHeader').height(), 10) / parseInt($(window).height(), 10) * 60)).toString() + "%");
	}
};


//function to check for mobile device
function isMobileDevice()
{
	"use strict";

	if (/Android|SamsungBrowser|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent))
	{
		return true;
	}
	else
	{
		return false;
	}
}

//adjust size of logo according to screen size
window.onresize = function() {
	"use strict";
	
	//$('#logo').css('width', parseInt($('#blueHeader').width(), 10) * 0.1);
	//$('#logo').css('height', parseInt($('#blueHeader').width(), 10)* 0.1);
	
	$('#logo').css('height', (parseInt($('#blueHeader').height()) + parseInt($('#blueHeader').css('padding-bottom'))).toString());
	$('#logo').css('width', (parseInt($('#blueHeader').height()) + parseInt($('#blueHeader').css('padding-bottom'))).toString());
	$('#websiteHeader').css('margin-left', $('#logo').width());	
	
};


function navigateTo(site) {
	window.location.href = site;
	
}