<?php

$conn;
$result;


function sendQuery($queryString, $showError = true)
{
	global $conn, $result;
	if ($result =$conn->query($queryString))
    {
    	return true;
    }
    else
    {
    	if ($showError) die("Error: " . $conn->error);	
    }
}

	$announcementID = -1;
	//if the script is called by a get request, then continue
	 if ($_SERVER['REQUEST_METHOD'] === 'POST')
    {
    	$announcementID = $_POST["id"];

		//create constant variables to hold the details of the sql server and credentials
		define("DB_NAME", "id69779_announcements");
		define("DB_USER", "id69779_root");
		define("DB_HOST", "localhost");
		define("DB_PASSWORD", "145willow21");
		
		//connect to the sql databse
		$conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
		
		//if connection fails, exit and send error message
		if ($conn->connect_error) {
			die("Could not connect: " . $conn->connect_error);
		}
		
		$announcementID = $conn->real_escape_string($announcementID);
		
		sendQuery("DELETE FROM " . DB_NAME . ".presetTable WHERE announcementID='" . $announcementID . "' LIMIT 1;");
	}
    else
    {

    }
?>