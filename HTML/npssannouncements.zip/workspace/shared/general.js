

/*global isMobileDevice*/

var $;



function navigateTo(site) {
	window.location.href = site;
	
}

//animate specified control with specified animation and remove any invisible classes
function animateControl(control, animation, setInvisible)
{
	"use strict";
	
	if (setInvisible)
	{
		//add the animated class and the specified animation class. when animation is finished, remove the animated class and remove the specified animation class
		$(control.toString()).addClass(' animated ' + animation.toString()).one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
	    $(this).removeClass('animated').removeClass(animation);
		//add the invisiblity class
		$(control.toString()).addClass(' invisible');	
	    });
	}
	else
	{
		//remove the invisiblity class if there
		$(control.toString()).removeClass('invisible');	
		//add the animated class and the specified animation class. when animation is finished, remove the animated class and remove the specified animation class
		$(control.toString()).addClass(' animated ' + animation.toString()).one('webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend', function(){
	    $(this).removeClass('animated').removeClass(animation);
	    });
	}
}

var isMenuOpen = false;

function showMobileMenu()
{
	if (!isMenuOpen)
	{
		animateControl("#mobileMenuBackground", "fadeInLeft", false);
		isMenuOpen = true;
		setTimeout(function() {
			$("#btnShowMenu").prependTo("#mobileMenu");
			$("#btnShowMenu").css("float", "none");
			$("#btnShowMenu").css("margin-left", "5%");
		}, 400);
	}
	else
	{
		animateControl("#mobileMenuBackground", "fadeOutLeft", true);
		isMenuOpen = false;
		setTimeout(function() {
			$("#btnShowMenu").prependTo("#containerHeader");
			$("#btnShowMenu").css("float", "left");
			$("#btnShowMenu").css("margin-left", "");

		}, 400);
	}
}

window.onclick = function(event)
{
	if (event.target == document.getElementById("mobileMenuBackground"))
	{
		showMobileMenu();
	}
}


function optimizeGeneralLayout()
{
	//adjust padding of main based on height of fixed header and adjust sizes
	$('#headerTitle').css('top', ("-" + parseInt($('#containerHeader').height()) * 0.36).toString() + "px");
	$('#headerLogo').css('height', parseInt($('#containerHeader').height()));
	$('#headerLogo').css('width', parseInt($('#containerHeader').height()));
	$('#btnShowMenu').css('height', parseInt($('#headerTitle').height()).toString() + "px");
	$('#btnShowMenu').css('width', parseInt($('#headerTitle').height()).toString() + "px");
	$('#btnShowMenu').css('max-height', (parseInt(window.outerWidth)*0.1).toString() + "px");
	$('#btnShowMenu').css('max-width', (parseInt(window.outerWidth)*0.1).toString() + "px");
	$('#main').css('height', 'initial');
	$('#navbar').css('top', ("-" + parseInt($('#containerHeader').height()) * 0.36).toString() + "px");
	
	if (isMobileDevice)
	{
		$('#main').css('width', window.outerWidth.toString() + "px");
		$('#txtTitle').css('width', '85%');
		$('#txtTeacherName').css('width', '85%');
		$('#txtLocation').css('width', '85%');
		$('#dropDownMonth').css('width', '22%');
		$('#dropDownDay').css('width', '22%');
		$('#dropDownYear').css('width', '22%');
		$('#dropDownSubject').css('width', '85%');
		$('#txtContent').css('width', '85%');
		$("#containerHeader").css("width", (window.outerWidth).toString() + "px");
	}
	else
	{

	}
}


window.addEventListener("orientationchange", function() {
	optimizeGeneralLayout();
});


function closeModal()
{
	$(".modal").css("display", "none");
}
