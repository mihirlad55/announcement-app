<?php

$conn;
$result;


function sendQuery($queryString, $showError = true)
{
	global $conn, $result;
	if ($result =$conn->query($queryString))
    {
    	return true;
    }
    else
    {
    	if ($showError) die("Error: " . $conn->error);	
    }
}
	
	//if a post request has been sent ot the html, then set the announcement object to the post object
	 if ($_SERVER['REQUEST_METHOD'] === 'POST')
    {
		$announcement = $_POST;
	
		//create constant variables to hold the details of the sql server and credentials
		define("DB_NAME", "id69779_announcements");
		define("DB_USER", "id69779_root");
		define("DB_HOST", "localhost");
		define("DB_PASSWORD", "145willow21");
		
		//connect to the sql databse
		$conn = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
		
		//if connection fails, exit and send error message
		if ($conn->connect_error) {
			die("Could not connect: " . $conn->connect_error);
		}
		
		sendQuery("SET time_zone = '-05:00'");
		
		//escape any quotation marks to avoid sql injections and command failures due to inappropriate characters in query
		$announcement["title"] = $conn->real_escape_string($announcement["title"]);
		session_start();
		$announcement["teacherName"] = $conn->real_escape_string($_SESSION["name"]);
		session_write_close();
		$announcement["subject"] = $conn->real_escape_string($announcement["subject"]);
		$announcement["content"] = $conn->real_escape_string($announcement["content"]);
		$announcement["deadline"] = $conn->real_escape_string($announcement["deadline"]);
		$announcement["location"] = $conn->real_escape_string($announcement["location"]);
		$announcement["target"] = $conn->real_escape_string($announcement["target"]);
	
		//define the query being sent to the sql server and insert the row
		sendQuery("INSERT INTO " . DB_NAME . ".presetTable VALUES (NULL, '" . $announcement["title"] . "','" . $announcement["teacherName"] . "','" . $announcement["subject"] . "','" . $announcement["content"] . "','" . $announcement["location"] . "',NULL,'" . $announcement["deadline"] . "','" . $announcement["target"] . "')");
    }
    else
    {

    }
	
?>